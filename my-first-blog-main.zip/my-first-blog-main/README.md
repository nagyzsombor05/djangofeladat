# my-first-blog

https://tutorial.djangogirls.org/hu/
